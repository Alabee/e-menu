<html>
<h1>Dinner Drinks</h1>
<body>
<form action="" method="post" enctype="multipart/form-data">
    <div style="width:400px;border-radius:6px;margin:0px auto">
        <table border="1">
            <tr>
                <td colspan="2">Beverages and Drinks:</td>
            </tr>
            <tr>
                <td>Mango Juice</td><td>Ksh.100</td>
                <td><input type="checkbox" name="Beverages and Drinks[]" value="Mango Juice"></td>

            </tr>
            <tr>
                <td>Apple Juice</td><td>Ksh.150</td>
                <td><input type="checkbox" name="Beverages and Drinks[]" value="Apple Juice"></td>
            </tr>
            <tr>
                <td>Piccana</td><td>Ksh.200</td>
                <td><input type="checkbox" name="Beverages and Drinks[]" value="Piccana"></td>
            </tr>
            <tr>
                <td>Soda</td><td>Ksh.50</td>
                <td><input type="checkbox" name="Beverages and Drinks[]" value="Soda"></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><input type="submit" value="0rder" name="sub"></td>
            </tr>
        </table>
    </div>
</form>
<?php
if(isset($_POST['Beverages and Drinks']))
{
    $host="localhost";//host name
    $username="root"; //database username
    $word="";//database word
    $db_name="emenu";//database name
    $tbl_name="emenu"; //table name
    $con=mysqli_connect("$host", "$username", "$word","$db_name")or die("cannot connect");//connection string
    $checkbox1=$_POST['Beverages and Drinks'];
    $chk="";
    foreach($checkbox1 as $chk1)
    {
        $chk .= $chk1.",";
    }
    $in_ch=mysqli_query($con,"insert into emenu(Beverages and Drinks) values ('$chk')");
    if($in_ch==1)
    {
        echo'<script>alert("Inserted Successfully")</script>';
    }
    else
    {
        echo'<script>alert("Failed To Insert")</script>';
    }
}
?>
</body>
</html>