<html>
<h1>Dinner Foods</h1>
<body>
<form action="" method="post" enctype="multipart/form-data">
    <div style="width:200px;border-radius:6px;margin:0px auto">
        <table border="1">
            <tr>
                <td colspan="2">Foods:</td>
            </tr>
            <tr>
                <td>Chips</td><td>Ksh.100</td>
                <td><input type="checkbox" name="Foods[]" value="Chips"></td>
            </tr>
            <tr>
                <td>Matoke</td><td>Ksh.70</td>
                <td><input type="checkbox" name="Foods[]" value="Matoke"></td>
            </tr>
            <tr>
                <td>Githeri</td><td>Ksh.50</td>
                <td><input type="checkbox" name="Foods[]" value="Githeri"></td>
            </tr>
            <tr>
                <td>Pilau</td> <td>Ksh.200</td>
                <td><input type="checkbox" name="Foods[]" value="Pilau"></td>
            </tr>
            <tr>
                <td>Ugali</td> <td>Ksh.30</td>
                <td><input type="checkbox" name="Foods[]" value="Ugali"></td>
            </tr>
            <tr>
                <td>Samaki</td> <td>Ksh.300</td>
                <td><input type="checkbox" name="Foods[]" value="Samaki"></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><input type="submit" value="0rder" name="sub"></td>
            </tr>
        </table>
    </div>
</form>
<?php
if(isset($_POST['Foods']))
{
    $host="localhost";//host name
    $username="root"; //database username
    $word="";//database word
    $db_name="emenu";//database name
    $tbl_name="emenu"; //table name
    $con=mysqli_connect("$host", "$username", "$word","$db_name")or die("cannot connect");//connection string
    $checkbox1=$_POST['Foods'];
    $chk="";
    foreach($checkbox1 as $chk1)
    {
        $chk .= $chk1.",";
    }
    $in_ch=mysqli_query($con,"insert into emenu(Foods) values ('$chk')");
    if($in_ch==1)
    {
        echo'<script>alert("Inserted Successfully")</script>';
    }
    else
    {
        echo'<script>alert("Failed To Insert")</script>';
    }
}
?>
</body>
</html>