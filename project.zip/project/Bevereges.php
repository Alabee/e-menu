<html>
<body>
<form action="" method="post" enctype="multipart/form-data">
    <div style="width:200px;border-radius:6px;margin:0px auto">
        <table border="1">
            <tr>
                <td colspan="2">Foods:</td>
            </tr>
            <tr>
                <td>White Cofee</td> <td>Ksh.50</td>
                <td><input type="checkbox" name="Foods[]" value="White Coffee"></td>
            </tr>
            <tr>
                <td>Black Coffee</td> <td>Ksh.70</td>
                <td><input type="checkbox" name="Foods[]" value="Black COffee"></td>
            </tr>
            <tr>
                <td>Black Tea</td> <td>Ksh.60</td>
                <td><input type="checkbox" name="Foods[]" value="Black Tea"></td>
            </tr>
            <tr>
                <td>Creamed Tea</td> <td>Ksh.200</td>
                <td><input type="checkbox" name="Foods[]" value="Cream Tea"></td>
            </tr>
            <tr>
                <td>Herbal Tea</td> <td>Ksh.150</td>
                <td><input type="checkbox" name="Foods[]" value="Herbal Tea"></td>
            </tr>
            <tr>
                <td>Green Tea</td> <td> Ksh. 120</td>
                <td><input type="checkbox" name="Foods[]" value="Green Tea"></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><input type="submit" value="0rder" name="sub"></td>
            </tr>
        </table>
    </div>
</form>
<?php
if(isset($_POST['Foods']))
{
    $host="localhost";//host name
    $username="root"; //database username
    $word="";//database word
    $db_name="emenu";//database name
    $tbl_name="emenu"; //table name
    $con=mysqli_connect("$host", "$username", "$word","$db_name")or die("cannot connect");//connection string
    $checkbox1=$_POST['Foods'];
    $chk="";
    foreach($checkbox1 as $chk1)
    {
        $chk .= $chk1.",";
    }
    $in_ch=mysqli_query($con,"insert into emenu(Foods) values ('$chk')");
    if($in_ch==1)
    {
        echo'<script>alert("Inserted Successfully")</script>';
    }
    else
    {
        echo'<script>alert("Failed To Insert")</script>';
    }
}
?>
</body>
</html>