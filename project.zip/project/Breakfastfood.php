<html>
<body>
<form action="" method="post" enctype="multipart/form-data">
    <div style="width:200px;border-radius:6px;margin:0px auto">
        <table border="1">
            <tr>
                <td colspan="2">Foods:</td>
            </tr>
            <tr>
                <td>arrowroots</td> <td>Ksh.100</td>
                <td><input type="checkbox" name="Foods[]" value="arrowroots"></td>
            </tr>
            <tr>
                <td>sweetpotatoes</td> <td>Ksh.90</td>
                <td><input type="checkbox" name="Foods[]" value="sweetpotatoes"></td>
            </tr>
            <tr>
                <td>maandazi</td> <td>Ksh.50</td>
                <td><input type="checkbox" name="Foods[]" value="maandazi"></td>
            </tr>
            <tr>
                <td>sausages</td> <td>Ksh.70</td>
                <td><input type="checkbox" name="Foods[]" value="sausages"></td>
            </tr>
            <tr>
                <td>smokies</td> <td>Ksh.60</td>
                <td><input type="checkbox" name="Foods[]" value="smokies"></td>
            </tr>
            <tr>
                <td>samosa</td> <td>Ksh.150</td>
                <td><input type="checkbox" name="Foods[]" value="samosa"></td>
            </tr>

            <tr>
                <td colspan="2" align="center"><input type="submit" value="0rder" name="sub"></td>
            </tr>
        </table>
    </div>
</form>
<?php
if(isset($_POST['Foods']))
{
    $host="localhost";//host name
    $username="root"; //database username
    $word="";//database word
    $db_name="emenu";//database name
    $tbl_name="emenu"; //table name
    $con=mysqli_connect("$host", "$username", "$word","$db_name")or die("cannot connect");//connection string
    $checkbox1=$_POST['Foods'];
    $chk="";
    foreach($checkbox1 as $chk1)
    {
        $chk .= $chk1.",";
    }
    $in_ch=mysqli_query($con,"insert into emenu(Foods) values ('$chk')");
    if($in_ch==1)
    {
        echo'<script>alert("Inserted Successfully")</script>';
    }
    else
    {
        echo'<script>alert("Failed To Insert")</script>';
    }
}
?>
</body>
</html>